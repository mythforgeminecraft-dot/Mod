# 🎮 Armor Durability Display Mod
### For Minecraft 1.21 (Fabric)

![Version](https://img.shields.io/badge/minecraft-1.21-green)
![Fabric](https://img.shields.io/badge/fabric-required-blue)

## 📋 Description

A **PvP-focused Fabric mod** that displays your armor durability when you press **Q** (drop key). Perfect for tracking your gear health during combat!

### ✨ Features

- 🎯 **Quick Durability Check**: Press Q to see all armor durability instantly
- 🎨 **Color-Coded Display**: 
  - 🟢 Green (75%+): Excellent condition
  - 🟡 Yellow (50-75%): Good condition  
  - 🟠 Orange (25-50%): Needs attention
  - 🔴 Red (10-25%): Low durability
  - 🔴 Dark Red (<10%): Critical!
- ⚡ **Action Bar Display**: Non-intrusive, appears above hotbar
- 🛡️ **All Armor Slots**: Helmet, Chestplate, Leggings, Boots
- 📊 **Exact Numbers**: Shows current/max durability (e.g., 245/364)

## 🎮 How to Use

1. Put on some armor
2. Press **Q** (drop key)
3. See your armor durability in the action bar!

**Example Display:**
```
⚔ ARMOR DURABILITY | ⛑ 350/364 | ⚔ 520/528 | ⛨ 490/495 | ⚓ 410/429
```

## 📦 Installation

### Pre-compiled JAR (Easy Method)

1. Download `armor-durability-display-1.0.0.jar`
2. Install [Fabric Loader](https://fabricmc.net/use/)
3. Install [Fabric API](https://modrinth.com/mod/fabric-api)
4. Place the JAR in your `.minecraft/mods/` folder
5. Launch Minecraft 1.21 with Fabric!

### Build from Source

#### Requirements:
- Java 21 or higher
- Gradle 8.5+ (or use included wrapper)

#### Build Steps:

```bash
# Clone or download this project
cd armor-durability-mod

# Build with Gradle
./gradlew build

# Or on Windows:
gradlew.bat build

# Find your JAR in:
# build/libs/armor-durability-display-1.0.0.jar
```

#### Quick Build Commands:

**Linux/Mac:**
```bash
chmod +x gradlew
./gradlew clean build
```

**Windows:**
```cmd
gradlew.bat clean build
```

The compiled mod will be in `build/libs/`

## 🔧 Dependencies

- **Minecraft**: 1.21
- **Fabric Loader**: 0.16.0+
- **Fabric API**: 0.102.0+1.21
- **Java**: 21+

## 📁 Project Structure

```
armor-durability-mod/
├── src/
│   └── main/
│       ├── java/com/armordurability/
│       │   ├── ArmorDurabilityMod.java        # Main mod class
│       │   ├── ArmorDurabilityClient.java     # Client initialization
│       │   └── ArmorDurabilityDisplay.java    # Display logic
│       └── resources/
│           ├── fabric.mod.json                # Mod metadata
│           └── assets/armordurability/
│               └── lang/en_us.json            # Translations
├── build.gradle                               # Build configuration
├── gradle.properties                          # Project properties
└── settings.gradle                            # Gradle settings
```

## 🎯 For Server Owners

This is a **client-side mod** - it doesn't need to be installed on servers! Players can use it on any server that allows Fabric mods.

## 🔍 Troubleshooting

### Build Errors

**"Task 'build' not found"**
- Make sure you're in the project directory
- Run `./gradlew tasks` to see available tasks

**"Java version too old"**
- Install Java 21: https://adoptium.net/

**"Could not resolve dependencies"**
- Check your internet connection
- Try: `./gradlew build --refresh-dependencies`

### Runtime Issues

**Mod doesn't load**
- Verify Fabric Loader is installed
- Install Fabric API mod
- Check logs in `.minecraft/logs/latest.log`

**Q key doesn't work**
- Make sure you're in-game (not in menus)
- Check keybind in Options > Controls > Armor Durability Display

## 🛠️ Development

Want to modify the mod? Here's how:

```bash
# Set up development environment
./gradlew idea      # For IntelliJ IDEA
./gradlew eclipse   # For Eclipse

# Run Minecraft with your mod in development
./gradlew runClient
```

## 📝 Customization Ideas

You can easily modify the mod to:
- Change the activation key (edit `ArmorDurabilityClient.java`)
- Adjust color thresholds (edit `ArmorDurabilityDisplay.java`)
- Add sound effects on low durability
- Show durability as percentages only
- Add durability warnings at specific thresholds

## 📄 License

MIT License - Free to use, modify, and distribute!

## 🤝 Contributing

Feel free to:
- Report bugs
- Suggest features  
- Submit pull requests
- Share with friends!

## 💡 Tips for PvP

- Check durability before engaging in combat
- Keep backup armor in your ender chest
- Repair armor at anvils between fights
- Use Mending enchantment for auto-repair

---

**Made with ❤️ for the Minecraft PvP community**

Enjoy knowing exactly when your armor needs repairs! 🛡️
