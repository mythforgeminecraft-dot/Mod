#!/bin/bash

echo "============================================"
echo " Armor Durability Display Mod - Builder"
echo "============================================"
echo ""

# Check for Java
if ! command -v java &> /dev/null; then
    echo "ERROR: Java not found!"
    echo "Please install Java 21 from: https://adoptium.net/"
    exit 1
fi

echo "Java version:"
java -version 2>&1 | head -1
echo ""

# Make gradlew executable
if [ -f "./gradlew" ]; then
    chmod +x gradlew
fi

echo "Building mod..."
echo ""

# Build with Gradle
if [ -f "./gradlew" ]; then
    ./gradlew clean build
else
    echo "ERROR: Gradle wrapper not found!"
    echo "Please install Gradle from: https://gradle.org/"
    exit 1
fi

if [ $? -eq 0 ]; then
    echo ""
    echo "============================================"
    echo " Build Successful!"
    echo "============================================"
    echo ""
    echo "Your mod JAR is located at:"
    echo "build/libs/armor-durability-display-1.0.0.jar"
    echo ""
    echo "Next steps:"
    echo "1. Install Fabric Loader for Minecraft 1.21"
    echo "2. Install Fabric API mod"
    echo "3. Copy the JAR to ~/.minecraft/mods/"
    echo "4. Launch Minecraft!"
    echo ""
else
    echo ""
    echo "Build failed! Check the errors above."
    echo ""
    exit 1
fi
