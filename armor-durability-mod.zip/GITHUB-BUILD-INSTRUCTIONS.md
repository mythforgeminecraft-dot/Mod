# 🚀 How to Build Your Mod on GitHub (Mobile-Friendly)

## 📱 Step-by-Step Instructions for Mobile Users

### ✅ What You Need:
- A GitHub account (free)
- The `armor-durability-mod-source.zip` file I gave you
- 5 minutes

---

## 📋 Instructions:

### 1️⃣ Create a GitHub Account
- Go to: https://github.com/signup
- Create a free account
- Verify your email

### 2️⃣ Create a New Repository

**On Mobile Browser:**
1. Go to: https://github.com/new
2. Repository name: `armor-durability-mod`
3. Description: `PvP Armor Durability Display Mod for Minecraft 1.21`
4. Make it **Public** (so Actions work free)
5. ✅ Check "Add a README file"
6. Click **"Create repository"**

### 3️⃣ Upload Your Files

**Option A - Mobile Browser (Easier):**
1. Extract the ZIP file on your phone
2. In your new GitHub repository, click **"Add file"** → **"Upload files"**
3. Select ALL files from the extracted folder:
   - All `.gradle` files
   - All `src/` folders
   - `build.gradle`
   - `gradle.properties`
   - `settings.gradle`
   - `gradlew`
   - `gradlew.bat`
   - `LICENSE`
   - `.github/` folder (IMPORTANT!)
4. Add commit message: "Initial commit"
5. Click **"Commit changes"**

**Option B - Using Git (Advanced):**
```bash
# Extract ZIP first, then:
cd armor-durability-mod
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR-USERNAME/armor-durability-mod.git
git push -u origin main
```

### 4️⃣ GitHub Builds Your Mod Automatically! 🎉

1. Go to your repository on GitHub
2. Click the **"Actions"** tab at the top
3. You'll see a workflow running called "Build Fabric Mod"
4. Wait 2-3 minutes for it to finish (green checkmark ✅)

### 5️⃣ Download Your Built JAR

**After the build finishes:**
1. Click on the completed workflow
2. Scroll down to **"Artifacts"**
3. Click **"armor-durability-display-mod"** to download
4. Extract the ZIP - inside is your `.jar` file!

---

## 🎯 Quick Links After Setup:

**To rebuild the mod later:**
- Just upload new code files to GitHub
- Or click **"Actions"** → **"Build Fabric Mod"** → **"Run workflow"**
- GitHub rebuilds it automatically!

**To download your JAR:**
- Go to: `https://github.com/YOUR-USERNAME/armor-durability-mod/actions`
- Click latest successful build
- Download artifact

---

## 🐛 Troubleshooting:

### ❌ "Actions" tab missing
- Make sure repository is **Public** (free Actions only work on public repos)
- Go to Settings → Actions → General → Enable "Allow all actions"

### ❌ Build fails
- Check you uploaded the `.github/workflows/build.yml` file
- Make sure you uploaded ALL files from the ZIP (especially `gradle/` folder)
- Click on the failed build to see error details

### ❌ Can't find built JAR
- Make sure build has green checkmark ✅
- Look under "Artifacts" section (scroll down on the workflow run page)

---

## 📦 What Gets Built:

GitHub creates: `armor-durability-display-1.0.0.jar`

This is ready to use in Minecraft!

---

## 💡 Pro Tips:

1. **Bookmark your Actions page**: `https://github.com/YOUR-USERNAME/armor-durability-mod/actions`
2. **Star your repository** so you can find it easily later
3. Every time you push code changes, GitHub automatically rebuilds your mod!
4. You can make the repository private later if you want (but Actions won't work on free tier)

---

## 🎮 After You Download the JAR:

1. Install Fabric Loader for MC 1.21
2. Install Fabric API mod
3. Put `armor-durability-display-1.0.0.jar` in `.minecraft/mods/`
4. Launch Minecraft and press **Q** to see armor durability!

---

**Need help?** The build process is fully automatic - GitHub does all the work! Just upload the files and wait. ⏰
