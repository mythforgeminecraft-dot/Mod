# 🚀 QUICK START GUIDE

## Option 1: Use Pre-Built JAR (Easiest - No Building Required!)

The mod source is ready to use, but needs to be compiled first. Follow **Option 2** to build it.

## Option 2: Build from Source (Recommended)

### Windows Users:

1. **Install Java 21** (if not installed)
   - Download from: https://adoptium.net/
   - Install and restart terminal

2. **Build the mod**
   ```cmd
   build-windows.bat
   ```

3. **Find your JAR**
   - Location: `build\libs\armor-durability-display-1.0.0.jar`

### Linux/Mac Users:

1. **Install Java 21** (if not installed)
   ```bash
   # Ubuntu/Debian
   sudo apt install openjdk-21-jdk
   
   # macOS (with Homebrew)
   brew install openjdk@21
   ```

2. **Build the mod**
   ```bash
   chmod +x build.sh
   ./build.sh
   ```

3. **Find your JAR**
   - Location: `build/libs/armor-durability-display-1.0.0.jar`

## Installation in Minecraft

### Step 1: Install Fabric Loader
- Go to https://fabricmc.net/use/
- Download installer for Minecraft 1.21
- Run installer, select version 1.21, click Install

### Step 2: Install Fabric API
- Download from: https://modrinth.com/mod/fabric-api
- Get version for Minecraft 1.21
- Place in `.minecraft/mods/` folder

### Step 3: Install This Mod
- Copy `armor-durability-display-1.0.0.jar` to `.minecraft/mods/`
- Launch Minecraft 1.21 with Fabric profile

### Step 4: Play!
- Join any server or singleplayer world
- Put on armor
- Press **Q** to see durability!

## Troubleshooting

### "gradlew: command not found" or "Access denied"
```bash
chmod +x gradlew
./gradlew clean build
```

### "Java version too old"
- Install Java 21 from https://adoptium.net/

### "Build failed"
- Make sure you have internet connection (downloads dependencies)
- Delete `.gradle` folder and try again
- Run: `./gradlew clean build --refresh-dependencies`

### Mod doesn't show in Minecraft
- Check you installed Fabric Loader correctly
- Check you have Fabric API mod installed
- Check logs: `.minecraft/logs/latest.log`

## Need Help?

Check the full README.md for detailed instructions and troubleshooting!

---

**TIP:** The JAR file will be created in `build/libs/` after building. That's the file you need to copy to your mods folder!
