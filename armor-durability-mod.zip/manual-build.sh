#!/bin/bash

# Manual Fabric Mod Build Script
set -e

MOD_DIR="/home/claude/armor-durability-mod"
BUILD_DIR="$MOD_DIR/build"
CLASSES_DIR="$BUILD_DIR/classes"
JAR_NAME="armor-durability-display-1.0.0.jar"

echo "Building Armor Durability Display Mod..."

# Clean build directory
rm -rf "$BUILD_DIR"
mkdir -p "$CLASSES_DIR"

# Note: This is a simplified build for demonstration
# In production, you'd need Fabric API and Minecraft dependencies
# This creates the structure and source files that can be compiled with proper Gradle setup

# Copy resources
echo "Copying resources..."
cp -r "$MOD_DIR/src/main/resources/"* "$CLASSES_DIR/"

# Create the JAR structure
cd "$CLASSES_DIR"

# Create a basic JAR (note: needs proper compilation with dependencies)
echo "Creating JAR structure..."
jar cvf "$BUILD_DIR/$JAR_NAME" .

echo "Build complete! JAR created at: $BUILD_DIR/$JAR_NAME"
echo ""
echo "IMPORTANT: This JAR needs to be compiled with proper Fabric/Minecraft dependencies."
echo "To build properly:"
echo "1. Install Gradle 8.5+"
echo "2. Run: ./gradlew build"
echo "3. Find JAR in: build/libs/"

ls -lh "$BUILD_DIR/$JAR_NAME"
