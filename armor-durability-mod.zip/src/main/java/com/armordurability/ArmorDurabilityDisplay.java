package com.armordurability;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ArmorDurabilityDisplay {
    
    public static void showArmorDurability(PlayerEntity player) {
        if (player == null) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return;

        // Check each armor slot
        ItemStack helmet = player.getEquippedStack(EquipmentSlot.HEAD);
        ItemStack chestplate = player.getEquippedStack(EquipmentSlot.CHEST);
        ItemStack leggings = player.getEquippedStack(EquipmentSlot.LEGS);
        ItemStack boots = player.getEquippedStack(EquipmentSlot.FEET);

        boolean hasArmor = !helmet.isEmpty() || !chestplate.isEmpty() || 
                          !leggings.isEmpty() || !boots.isEmpty();

        if (!hasArmor) {
            player.sendMessage(Text.literal("§c§l✗ §7No armor equipped!"), true);
            return;
        }

        // Build armor durability message
        StringBuilder message = new StringBuilder();
        message.append("§6§l⚔ ARMOR DURABILITY §r§8| ");

        boolean first = true;

        // Helmet
        if (!helmet.isEmpty() && helmet.isDamageable()) {
            if (!first) message.append(" §8| ");
            message.append(getArmorText("⛑", helmet));
            first = false;
        }

        // Chestplate
        if (!chestplate.isEmpty() && chestplate.isDamageable()) {
            if (!first) message.append(" §8| ");
            message.append(getArmorText("⚔", chestplate));
            first = false;
        }

        // Leggings
        if (!leggings.isEmpty() && leggings.isDamageable()) {
            if (!first) message.append(" §8| ");
            message.append(getArmorText("⛨", leggings));
            first = false;
        }

        // Boots
        if (!boots.isEmpty() && boots.isDamageable()) {
            if (!first) message.append(" §8| ");
            message.append(getArmorText("⚓", boots));
            first = false;
        }

        // Send as action bar
        player.sendMessage(Text.literal(message.toString()), true);
    }

    private static String getArmorText(String icon, ItemStack item) {
        if (!item.isDamageable()) {
            return "§a" + icon + " §f∞";
        }

        int maxDurability = item.getMaxDamage();
        int currentDamage = item.getDamage();
        int remaining = maxDurability - currentDamage;
        double percentage = (double) remaining / maxDurability * 100;

        String color;
        if (percentage > 75) {
            color = "§a"; // Green
        } else if (percentage > 50) {
            color = "§e"; // Yellow
        } else if (percentage > 25) {
            color = "§6"; // Gold
        } else if (percentage > 10) {
            color = "§c"; // Red
        } else {
            color = "§4"; // Dark Red
        }

        return color + icon + " §f" + remaining + "§7/§f" + maxDurability;
    }
}
